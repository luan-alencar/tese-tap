package com.unifacisa.tap.restclientservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestclientserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
