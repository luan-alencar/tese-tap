package com.unifacisa.tap.restclientservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestclientserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestclientserviceApplication.class, args);
	}

}
